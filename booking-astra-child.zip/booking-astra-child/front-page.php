<?php
/**
 * Custom Home Page Template
 * Hero, CTAs, Featured sections, Why Choose Us, Testimonials, WhatsApp strip
 *
 * @package Booking_Astra_Child
 */

defined( 'ABSPATH' ) || exit;

get_header();

/* WhatsApp number - set in Theme Customizer or use default */
$whatsapp_number = get_theme_mod( 'booking_whatsapp_number', '966500000000' );
$whatsapp_message = rawurlencode( 'Assalamu Alaikum, I would like to inquire about your services.' );
$whatsapp_link = 'https://wa.me/' . preg_replace( '/[^0-9]/', '', $whatsapp_number ) . '?text=' . $whatsapp_message;
?>

<main id="content" class="site-main">
	<div class="ast-container">

		<!-- Hero Banner + CTA Buttons -->
		<section class="booking-hero">
			<h1><?php echo esc_html( get_bloginfo( 'name' ) ); ?></h1>
			<p style="font-size: 1.2rem; max-width: 600px; margin: 0 auto;"><?php echo esc_html( get_bloginfo( 'description' ) ); ?></p>
			<div class="booking-cta-buttons">
				<a href="<?php echo esc_url( home_url( '/pick-drop/' ) ); ?>">Book Pick & Drop</a>
				<a href="<?php echo esc_url( home_url( '/ziyarat-packages/' ) ); ?>">View Packages</a>
				<a href="<?php echo esc_url( home_url( '/shop/' ) ); ?>">Shop</a>
				<a href="<?php echo esc_url( home_url( '/donations/' ) ); ?>">Donate</a>
			</div>
		</section>

		<!-- Featured Packages (placeholder - dynamic in Phase 2) -->
		<section class="booking-section">
			<h2>Featured Ziyarat Packages</h2>
			<p style="text-align: center; max-width: 600px; margin: 0 auto 24px;">Discover our curated packages for Makkah, Madinah, and beyond.</p>
			<div class="booking-trust-grid">
				<div class="booking-trust-item">
					<h3>Makkah Half Day</h3>
					<p>Visit key sites in Makkah with an experienced guide.</p>
					<a href="<?php echo esc_url( home_url( '/ziyarat-packages/' ) ); ?>" class="ast-button">View Details</a>
				</div>
				<div class="booking-trust-item">
					<h3>Madinah Ziyarat</h3>
					<p>Full day tour of Madinah's sacred places.</p>
					<a href="<?php echo esc_url( home_url( '/ziyarat-packages/' ) ); ?>" class="ast-button">View Details</a>
				</div>
				<div class="booking-trust-item">
					<h3>Taif & Badr</h3>
					<p>Extended trips to Taif, Badr, and historical sites.</p>
					<a href="<?php echo esc_url( home_url( '/ziyarat-packages/' ) ); ?>" class="ast-button">View Details</a>
				</div>
			</div>
		</section>

		<!-- Why Choose Us / Trust Points -->
		<section class="booking-section alt-bg">
			<h2>Why Choose Us</h2>
			<div class="booking-trust-grid">
				<div class="booking-trust-item">
					<h3>Trusted Service</h3>
					<p>Years of experience serving pilgrims and travelers in Saudi Arabia.</p>
				</div>
				<div class="booking-trust-item">
					<h3>Transparent Pricing</h3>
					<p>No hidden fees. Clear rates for all our services.</p>
				</div>
				<div class="booking-trust-item">
					<h3>24/7 Support</h3>
					<p>Contact us anytime via WhatsApp for quick assistance.</p>
				</div>
				<div class="booking-trust-item">
					<h3>Halal & Ethical</h3>
					<p>We operate with Islamic values in every service we provide.</p>
				</div>
			</div>
		</section>

		<!-- Testimonials (placeholder) -->
		<section class="booking-section">
			<h2>What Our Customers Say</h2>
			<div class="booking-trust-grid">
				<div class="booking-trust-item">
					<p><em>"Excellent pickup service from the airport. Very reliable and on time."</em></p>
					<p><strong>— Abdullah, Jeddah</strong></p>
				</div>
				<div class="booking-trust-item">
					<p><em>"The Ziyarat package was well organised. Highly recommend for families."</em></p>
					<p><strong>— Fatima, Pakistan</strong></p>
				</div>
				<div class="booking-trust-item">
					<p><em>"Great quality dates and fast delivery. Will order again!"</em></p>
					<p><strong>— Ahmed, Riyadh</strong></p>
				</div>
			</div>
		</section>

		<!-- WhatsApp Contact Strip -->
		<section class="booking-whatsapp-strip">
			<p style="margin: 0;">
				Need help? Contact us on WhatsApp &rarr;
				<a href="<?php echo esc_url( $whatsapp_link ); ?>" target="_blank" rel="noopener">Chat Now</a>
			</p>
		</section>

	</div>
</main>

<?php
get_footer();
